HOST = "irc.twitch.tv"
PORT = 6667
PASS = "oauth:"                                     #oauth token for the bot (incloude oauth: at start)
BOT = ""                                            #Bot acount username (Lowercase only!!!)
CHANNEL = ""                                        #Channel you whant the bot to join (Lowercase only!!!)
ClientID = ""                                       #Your Twitch OAuth Client ID
OAuth = ""                                          #The OAuth tocken for the channle you whant to connect to (DONT incloude oauth: at start)

MODS = ["fluxcabury", "notgamesbot"]                #Add the list of Mods in on the twitch channel
JoinMessage = ("NotGamesBot Joined the game.")      #message sent to the chat when joining the server
